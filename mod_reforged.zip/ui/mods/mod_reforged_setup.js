var Reforged = {
	mID : "mod_reforged",
	mJSConnectionID : "ReforgedJSConnection"
}
